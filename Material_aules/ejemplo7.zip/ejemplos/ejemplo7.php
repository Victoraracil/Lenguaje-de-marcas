<!DOCTYPE html>
<html>
<body>
	<h1>Formulario de alta</h1>
	<form action="form.php" method="post">
		Nombre:
		<input type="text" name="nombre" maxlength="50"><br>
		Contraseña:
		<input type="password" name="password"><br>
		Educacion:
		<select name="educacion">
			<option value="sin-estudios">Sin estudios</option>
			<option value="educacion-obligatoria" selected="selected">ESO</option>
			<option value="bachillerato">Bachillerato</option>
			<option value="formacion-profesional">Formación profesional</option>
			<option value="universidad">Universidad</option>
		</select> <br>
		Nacionalidad:
		<input type="radio" name="nacionalidad" value="español">España</input>
		<input type="radio" name="nacionalidad" value="otra">Otra</input><br>
		Idiomas:
		<input type="checkbox" name="idiomas[]" value="español" checked="checked">Español</input>
		<input type="checkbox" name="idiomas[]" value="inglés">Inglés</input>
		<input type="checkbox" name="idiomas[]" value="francés">Francés</input>
		<input type="checkbox" name="idiomas[]" value="aleman">Valenciano</input><br>
		Email:
		<input type="text" name="email"><br>
		Sitio Web:
		<input type="text" name="sitioweb"><br>
		<input type="submit" name="submit" value="Enviar datos">
	</form>
	<!-- array de errores $errores guarda cada uno de los errores que se registran para luego mostrarlos -->
	<ul>
		<?php if(isset($errores)){
			foreach ($errores as $error){
				echo "<li> $error </li>";
			}
		}
		?>
	</ul>
</body>
</html>
</form>
</body>
</html>