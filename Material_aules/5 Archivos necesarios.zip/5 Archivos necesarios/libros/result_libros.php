﻿<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="utf8">
	<title>Ejercicio recogida de datos de formulario - PHP</title>
</head>
<body>
	<h1>Resultado del formulario de búsqueda</h1>
	<p>Estos son los datos introducidos:</p>
		<!-- Introducir a continuación el codigo -->

		
		
</body>
</html>