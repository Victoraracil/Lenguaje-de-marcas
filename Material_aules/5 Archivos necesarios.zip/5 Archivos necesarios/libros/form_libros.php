﻿<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="utf8">
	<title>Ejercicio recogida de datos de formulario - PHP</title>
</head>
<body>
	<h1>Buscador de libros</h1>
	<form action="result_libros.php" method="post">
		<label for="texto">Texto de búsqueda:</label>
		<input type="text" name="texto" id="texto" size="30">
		<br>
		<label>Buscar en:</label>
		<blockquote>
		<input type="radio" name="buscaren" id="buscarentitulo" value="Título" checked="checked">
		<label for="buscarentitulo">Título del libro</label>&nbsp;&nbsp;
		<br><input type="radio" name="buscaren" id="buscarenautor" value="Autor">
		<label for="buscarenautor">Nombre del autor</label>&nbsp;&nbsp;
		<br><input type="radio" name="buscaren" id="buscareneditorial" value="Editorial">
		<label for="buscareneditorial">Editorial</label>
		</blockquote>
		
		<label for="genero">Tipo de libro:</label>
		<select name="genero" id="genero">
			<option value="Narrativa">Narrativa</option>
			<option value="Libros de texto">Libros de texto</option>
			<option value="Guias">Guías y mapas</option>
		</select>
		<br>
		<input type="submit" value="Buscar">
	</form>
</body>
</html>