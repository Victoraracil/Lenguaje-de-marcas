﻿<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="utf8">
	<title>Ejercicio recogida de datos de formulario - PHP</title>
</head>
<body>
	<h1>Seleccionar archivo</h1>
	<form action="subir_imagen.php" method="post" enctype="multipart/form-data">
		<label>Título: 
			<input type="text" name="titulo" id="titulo">
		</label>
		<br>
		<input type="file" name="fichero">
		<br>
		<input type="submit" value="Enviar">
	</form>
</body>
</html>