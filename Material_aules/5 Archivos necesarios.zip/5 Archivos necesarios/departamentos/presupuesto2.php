﻿<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="utf8">
	<title>Ejercicio recogida de datos de formulario - PHP</title>
</head>
<body>
	<?php	
		// Introducir comprobación cuando queramos que aparezca formulario
		
			
	?>
		<h1>Seleccionar departamento</h1>
		<form action="............" method="post">
			<select name="departamento">
				<option value="INF">Informática</option>
				<option value="LEN">Lengua</option>
				<option value="MAT">Matemáticas</option>
				<option value="ING">Inglés</option>
			</select>
			<br>
			<input type="submit" value="Enviar">
		</form>	
	<?php
		// Sí se ha enviado departamento, mostramos su presupuesto
			$depto = $_REQUEST['departamento'];
			$presup = 0;
			if ($depto == 'INF')
			{
				$presup = 500;
			} else if ($depto == 'LEN' || $depto == 'MAT') {
				$presup = 300;
			} else {
				$presup = 200;
			}
			echo "<h1>Presupuesto asignado</h1>";
			echo "<p>El presupuesto asignado a tu departamento es de $presup euros.</p>";
		}
	?>
</body>
</html>