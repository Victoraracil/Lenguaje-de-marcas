﻿<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="utf8">
	<title>Ejercicio recogida de datos de formulario - PHP</title>
</head>
<body>
	<h1>Seleccionar departamento</h1>
	<ul>
		<li><a href="presupuesto2.php">Informática</a></li>
		<li><a href="presupuesto2.php">Lengua</a></li>
		<li><a href="presupuesto2.php">Matemáticas</a></li>
		<li><a href="presupuesto2.php">Inglés</a></li>
		<li><a href="presupuesto2.php">Seleccionar despues</a></li>
	</ul>
</body>
</html>