﻿<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="utf8">
	<title>Ejercicio recogida de datos de formulario - PHP</title>
</head>
<body>
	<h1>Seleccionar departamento</h1>
	<form action="presupuesto.php" method="post">
		<select name="departamento">
			<option value="INF">Informática</option>
			<option value="LEN">Lengua</option>
			<option value="MAT">Matemáticas</option>
			<option value="ING">Inglés</option>
		</select>
		<br>
		<input type="submit" value="Enviar">
	</form>
</body>
</html>