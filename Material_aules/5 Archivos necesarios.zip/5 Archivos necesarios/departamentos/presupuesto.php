﻿<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="utf8">
	<title>Ejercicio recogida de datos de formulario - PHP</title>
</head>
<body>
	<?php
		// Introducir el codigo
		
		
	?>
</body>
</html>