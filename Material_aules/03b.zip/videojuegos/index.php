<?php

	require('conexion.inc');

	$consulta = $pdo->prepare("SELECT * FROM videojuegos");

	if (isset($_REQUEST['precio']) && !empty($_REQUEST['precio']) &&
			floatval($_REQUEST['precio']) >= 0)
	{
		$consulta = $pdo->prepare("SELECT * FROM videojuegos WHERE precio <= :precio");
		$consulta->bindParam(':precio', $_REQUEST['precio']);
	}
	
	$consulta->execute();	
?>

<!DOCTYPE html>
<html>
<body>
<h1>Listado de videojuegos</h1>

<p><a href="form_videojuego.php">Insertar videojuego</a></p>

<form action="<?= $_SERVER['PHP_SELF'] ?>">
	<label>
		Precio mínimo:
		<input type="number" step="0.01" min="0" name="precio">
	</label>
	<input type="submit" value="Buscar">
</form>

<ul>
	<?php
	while($registro = $consulta->fetch())
	{
		echo "<li>" . $registro['titulo'] . " (" . 
			$registro['genero'] . ", " . $registro['precio'] . " eur)</li>";
	}
	?>
</ul>
</body>
</html>
	
