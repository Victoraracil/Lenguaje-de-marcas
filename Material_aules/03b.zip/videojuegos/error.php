<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Error</title>
</head>
<body>
    <h1>Error en la aplicación</h1>    
    <p><?= $_REQUEST['mensaje'] ?></p>
</body>
</html>