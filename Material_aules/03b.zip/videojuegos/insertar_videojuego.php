<?php

	require('conexion.inc');

	$formularioOK = TRUE;
	$error = FALSE;

	if (!isset($_REQUEST['titulo']) || empty($_REQUEST['titulo']))
	{
		$formularioOK = FALSE;
	}
	elseif (!isset($_REQUEST['genero']) || empty($_REQUEST['genero']))
	{
		$formularioOK = FALSE;
	}
	elseif (!isset($_REQUEST['precio']) || empty($_REQUEST['precio']) || 
			floatval($_REQUEST['precio']) < 0)
	{
		$formularioOK = FALSE;
	}
	
	if ($formularioOK)
	{
		$insercion = $pdo->prepare("INSERT INTO videojuegos (titulo, genero, precio) " .
			"VALUES (:titulo, :genero, :precio)");
		$insercion->bindParam(':titulo', $_REQUEST['titulo']);
		$insercion->bindParam(':genero', $_REQUEST['genero']);
		$insercion->bindParam(':precio', $_REQUEST['precio']);
		if ($insercion->execute())		
			header("Location:index.php");
		else
			$error = TRUE;
	}

	if (!$formularioOK || $error)
	{
		$mensaje = "Error insertando videojuego";
		header("Location:error.php?mensaje=$mensaje");
	}
?>
	
