<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Inserción de videojuego</title>
</head>
<body>
    <form action="insertar_videojuego.php" method="post">
        <label>
            Título: 
            <input type="text" id="titulo" name="titulo" required>
        </label>
        <br>
        <label>
            Género: 
            <select id="genero" name="genero" required>
                <option value="Deportes">Deportes</option>
                <option value="Plataformas">Plataformas</option>
                <option value="FPS">First Person Shooter</option>
            </select>
        </label>
        <br>
        <label>
            Precio: 
            <input type="number" id="precio" name="precio" min="0" required step="0.01">
        </label>
        <br>
        <input type="submit" value="Enviar">
    </form>
</body>
</html>