<?php

	require('conexion.inc');

	$consulta = $pdo->prepare("SELECT * FROM videojuegos");
	$consulta->execute();	
?>

<!DOCTYPE html>
<html>
<body>
<h1>Listado de videojuegos</h1>

<p><a href="form_videojuego.php">Insertar videojuego</a></p>

<ul>
	<?php
	while($registro = $consulta->fetch())
	{
		echo "<li>" . $registro['titulo'] . " (" . 
			$registro['genero'] . ", " . $registro['precio'] . " eur)</li>";
	}
	?>
</ul>
</body>
</html>
	
