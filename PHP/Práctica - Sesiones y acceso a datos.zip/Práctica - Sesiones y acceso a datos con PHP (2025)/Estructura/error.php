<p style="color:red;">Los campos no pueden estar vacíos o ha ocurrido un error al insertar.</p>
<a href="nuevo_hotel.php">Volver</a>
