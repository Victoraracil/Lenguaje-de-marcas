<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hemeroteca</title>
</head>
<body>
    <h1>Bienvenido a la Hemeroteca</h1>
    <p>Seleccione una opción:</p>
    <ul>
        <li><a href="subir.php">Subir un archivo</a></li>
        <li><a href="listar.php">Ver archivos subidos</a></li>
    </ul>
</body>
</html>