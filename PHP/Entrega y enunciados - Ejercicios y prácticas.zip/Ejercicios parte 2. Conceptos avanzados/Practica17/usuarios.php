<?php
// Array que contiene parejas de datos usuario-contraseña
$usuarios = array(
    "Juan" => "draco",
    "Luisa" => "baobab",
    "Antonio" => "olmo"
);
?>