<?php
function pesetas_a_euros($pesetas) {
    return $pesetas / 166.368;
}

function euros_a_pesetas($euros) {
    return $euros * 166.368;
}
?>